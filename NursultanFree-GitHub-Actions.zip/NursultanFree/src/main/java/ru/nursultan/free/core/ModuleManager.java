package ru.nursultan.free.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

public class ModuleManager {
    private final List<ClientModule> modules = new ArrayList<>();

    public void register(ClientModule module) { modules.add(module); }
    public List<ClientModule> getModules() { return Collections.unmodifiableList(modules); }

    public ClientModule getByName(String name) {
        for (ClientModule module : modules) {
            if (module.getName().equalsIgnoreCase(name)) return module;
        }
        return null;
    }

    public void onTick(MinecraftClient client) {
        for (ClientModule module : modules) if (module.isEnabled()) module.onTick(client);
    }

    public void onHudRender(MinecraftClient client, MatrixStack matrices, float tickDelta) {
        for (ClientModule module : modules) if (module.isEnabled()) module.onHudRender(client, matrices, tickDelta);
    }
}
