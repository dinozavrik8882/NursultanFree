package ru.nursultan.free.module;

import net.minecraft.client.MinecraftClient;
import ru.nursultan.free.core.ClientModule;

public class ToggleSprintModule extends ClientModule {
    public ToggleSprintModule() { super("Toggle Sprint", "Keeps sprint active while moving forward"); }
    @Override public void onTick(MinecraftClient client) {
        if (client.player == null || client.options == null || client.currentScreen != null) return;
        if (client.options.keyForward.isPressed() && !client.player.isSneaking()
                && client.player.getHungerManager().getFoodLevel() > 6) {
            client.player.setSprinting(true);
        }
    }
}
