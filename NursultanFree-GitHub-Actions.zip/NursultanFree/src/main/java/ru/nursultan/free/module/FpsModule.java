package ru.nursultan.free.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import ru.nursultan.free.core.ClientModule;

public class FpsModule extends ClientModule {
    public FpsModule() { super("FPS HUD", "Displays the current frame rate"); }

    @Override
    public void onHudRender(MinecraftClient client, MatrixStack matrices, float tickDelta) {
        if (client.textRenderer == null) return;
        String text = "FPS: " + String.valueOf(client.getCurrentFps());
        client.textRenderer.drawWithShadow(matrices, text, 6.0F, 6.0F, 0xFF55FFFF);
    }
}
