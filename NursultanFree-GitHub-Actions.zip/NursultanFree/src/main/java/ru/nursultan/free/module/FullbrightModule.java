package ru.nursultan.free.module;

import net.minecraft.client.MinecraftClient;
import ru.nursultan.free.core.ClientModule;

public class FullbrightModule extends ClientModule {
    private double previousGamma = 1.0D;
    public FullbrightModule() { super("Fullbright", "Raises local brightness without changing the world"); }
    @Override public void onEnable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options != null) { previousGamma = client.options.gamma; client.options.gamma = 1.0D; }
    }
    @Override public void onDisable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options != null) client.options.gamma = previousGamma;
    }
}
