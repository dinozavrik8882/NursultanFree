package ru.nursultan.free.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import ru.nursultan.free.core.ClientModule;

public class CoordinatesModule extends ClientModule {
    public CoordinatesModule() { super("Coordinates", "Displays your current position"); }
    @Override public void onHudRender(MinecraftClient client, MatrixStack matrices, float tickDelta) {
        if (client.player == null || client.textRenderer == null) return;
        double x = client.player.getX(), y = client.player.getY(), z = client.player.getZ();
        String text = String.format(java.util.Locale.ROOT, "XYZ: %.1f / %.1f / %.1f", x, y, z);
        client.textRenderer.drawWithShadow(matrices, text, 6.0F, 20.0F, 0xFF55FFFF);
    }
}
