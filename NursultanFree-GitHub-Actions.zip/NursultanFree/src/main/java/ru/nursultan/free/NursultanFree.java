package ru.nursultan.free;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import ru.nursultan.free.config.ConfigManager;
import ru.nursultan.free.core.ModuleManager;
import ru.nursultan.free.module.FpsModule;
import ru.nursultan.free.module.CoordinatesModule;
import ru.nursultan.free.module.FullbrightModule;
import ru.nursultan.free.module.ToggleSprintModule;
import ru.nursultan.free.module.KeystrokesModule;
import ru.nursultan.free.ui.ClickGuiScreen;

public class NursultanFree implements ClientModInitializer {
    public static final String NAME = "Nursultan Free";
    public static final String VERSION = "2.0.0";
    public static final ModuleManager MODULES = new ModuleManager();
    public static final ConfigManager CONFIG = new ConfigManager();
    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        MODULES.register(new FpsModule());
        MODULES.register(new CoordinatesModule());
        MODULES.register(new FullbrightModule());
        MODULES.register(new ToggleSprintModule());
        MODULES.register(new KeystrokesModule());
        CONFIG.load(MODULES);

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nursultan_free.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.nursultan_free"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.openScreen(new ClickGuiScreen());
                }
            }
            MODULES.onTick(client);
        });

        net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback.EVENT.register((matrices, tickDelta) -> {
            MODULES.onHudRender(MinecraftClient.getInstance(), matrices, tickDelta);
        });

        System.out.println(NAME + " " + VERSION + " initialized");
    }
}
