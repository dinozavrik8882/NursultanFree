package ru.nursultan.free.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;
import ru.nursultan.free.core.ClientModule;
import ru.nursultan.free.core.ModuleManager;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("nursultan-free.json");

    public void save(ModuleManager manager) {
        JsonObject root = new JsonObject();
        for (ClientModule module : manager.getModules()) root.addProperty(module.getName(), module.isEnabled());
        try {
            Files.createDirectories(file.getParent());
            Files.write(file, GSON.toJson(root).getBytes(StandardCharsets.UTF_8));
        } catch (IOException exception) {
            System.err.println("Nursultan Free: config save failed: " + exception.getMessage());
        }
    }

    public void load(ModuleManager manager) {
        if (!Files.exists(file)) return;
        try {
            String json = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
            JsonObject root = new JsonParser().parse(json).getAsJsonObject();
            for (ClientModule module : manager.getModules()) {
                if (root.has(module.getName())) module.setEnabled(root.get(module.getName()).getAsBoolean());
            }
        } catch (Exception exception) {
            System.err.println("Nursultan Free: config load failed: " + exception.getMessage());
        }
    }
}
