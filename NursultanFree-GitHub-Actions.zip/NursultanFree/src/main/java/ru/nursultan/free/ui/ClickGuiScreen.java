package ru.nursultan.free.ui;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.LiteralText;
import ru.nursultan.free.NursultanFree;
import ru.nursultan.free.core.ClientModule;

public class ClickGuiScreen extends Screen {
    public ClickGuiScreen() { super(new LiteralText("Nursultan Free")); }

    @Override
    protected void init() {
        int buttonWidth = 220;
        int x = (this.width - buttonWidth) / 2;
        int y = Math.max(45, this.height / 4);
        for (ClientModule module : NursultanFree.MODULES.getModules()) {
            addButton(new ButtonWidget(x, y, buttonWidth, 20,
                    getModuleLabel(module), button -> {
                module.toggle();
                button.setMessage(getModuleLabel(module));
            }));
            y += 26;
        }
        addButton(new ButtonWidget(x, y + 8, buttonWidth, 20,
                new LiteralText("Save settings"), button -> NursultanFree.CONFIG.save(NursultanFree.MODULES)));
        addButton(new ButtonWidget(x, y + 34, buttonWidth, 20,
                new LiteralText("Done"), button -> close()));
    }

    private LiteralText getModuleLabel(ClientModule module) {
        return new LiteralText(module.getName() + ": " + (module.isEnabled() ? "ON" : "OFF"));
    }

    @Override
    public void render(net.minecraft.client.util.math.MatrixStack matrices, int mouseX, int mouseY, float delta) {
        renderBackground(matrices);
        int panelWidth = 270;
        int panelHeight = Math.min(height - 36, 390);
        int left = (width - panelWidth) / 2;
        int top = (height - panelHeight) / 2;
        fill(matrices, left - 2, top - 2, left + panelWidth + 2, top + panelHeight + 2, 0xFF35D9FF);
        fill(matrices, left, top, left + panelWidth, top + panelHeight, 0xEE101322);
        fill(matrices, left, top, left + panelWidth, top + 34, 0xFF211A3D);
        drawCenteredText(matrices, textRenderer, new LiteralText("NURSULTAN FREE  //  NEON"), width / 2, top + 12, 0xFF55FFFF);
        drawCenteredText(matrices, textRenderer, new LiteralText("RIGHT SHIFT  •  MODULES"), width / 2, top + panelHeight - 16, 0xFFB68CFF);
        super.render(matrices, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
