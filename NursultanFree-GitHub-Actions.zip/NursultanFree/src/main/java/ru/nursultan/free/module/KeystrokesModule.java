package ru.nursultan.free.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import ru.nursultan.free.core.ClientModule;

public class KeystrokesModule extends ClientModule {
    public KeystrokesModule() { super("Keystrokes", "Shows movement key states"); }
    @Override public void onHudRender(MinecraftClient client, MatrixStack matrices, float tickDelta) {
        if (client.options == null || client.textRenderer == null) return;
        int color = 0xFF55FFFF;
        String w = key("W", client.options.keyForward.isPressed());
        String a = key("A", client.options.keyLeft.isPressed());
        String s = key("S", client.options.keyBack.isPressed());
        String d = key("D", client.options.keyRight.isPressed());
        client.textRenderer.drawWithShadow(matrices, w, 6, 42, color);
        client.textRenderer.drawWithShadow(matrices, a + "  " + s + "  " + d, 6, 54, color);
    }
    private String key(String name, boolean pressed) { return pressed ? "[" + name + "]" : " " + name + " "; }
}
