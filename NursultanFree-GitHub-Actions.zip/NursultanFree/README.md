# Nursultan Free — Neon Edition

Client-side utility mod for Minecraft 1.16.5 using Fabric.

## Included modules
- FPS HUD
- Coordinates HUD
- Keystrokes HUD
- Fullbright (local gamma setting)
- Toggle Sprint (uses the normal client sprint state)
- Neon-themed ClickGUI (Right Shift)
- JSON configuration in `.minecraft/config/nursultan-free.json`

## Requirements
- Minecraft 1.16.5
- Fabric Loader and Fabric API for Minecraft 1.16.5
- Java 8 for local development
- GitHub account for automatic cloud builds

## Build locally
With Gradle 7.6.4 installed, run:

```bash
gradle --no-daemon clean build
```

The mod JAR is written to `build/libs/`.

## Automatic GitHub builds
The repository includes `.github/workflows/build.yml`.

1. Create a new empty repository on GitHub.
2. Extract this project ZIP on your computer.
3. Open a terminal in the extracted `NursultanFree` folder.
4. Initialize Git and push the project:

```bash
git init
git add .
git commit -m "Initial Nursultan Free source"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

5. Open the repository on GitHub and select **Actions**.
6. Open **Build Nursultan Free**. The workflow runs on every push and pull request.
7. When the run finishes successfully, open that run, scroll to **Artifacts**, and download `nursultan-free-minecraft-1.16.5`.
8. The downloaded ZIP contains the compiled `.jar` file.

You can also start a build manually from **Actions → Build Nursultan Free → Run workflow**.

## Notes
The workflow uses Java 8 and Gradle 7.6.4, then uploads the compiled JAR as a GitHub Actions artifact for 14 days.

This project focuses on client-side HUD and quality-of-life features. It does not include aim automation, reach modification, player-tracking ESP, or other modules that automate combat or alter server-authoritative gameplay.
